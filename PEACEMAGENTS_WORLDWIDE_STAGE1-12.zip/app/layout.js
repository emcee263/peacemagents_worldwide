import "./globals.css";
export const metadata={title:"PEACEMAGENTS WORLDWIDE — Streetwear for the calm rebels",description:"PEACEMAGENTS Worldwide. Bold, minimal streetwear for calm rebels."};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}